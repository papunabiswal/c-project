
#ifndef TODO_H
#define TODO_H

#define MAX_TASK_LENGTH 100

typedef struct {
    int id;
    char description[MAX_TASK_LENGTH];
    int completed;
} Task;

void loadTasks(Task **tasks, int *count);
void saveTasks(Task *tasks, int count);
void addTask(Task **tasks, int *count, const char *desc);
void listTasks(Task *tasks, int count);
void completeTask(Task *tasks, int count, int id);

#endif
