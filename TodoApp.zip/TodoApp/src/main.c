
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/todo.h"

int main() {
    Task *tasks = NULL;
    int count = 0;
    loadTasks(&tasks, &count);

    while (1) {
        printf("\n-- ToDo List --\n");
        printf("1. List Tasks\n");
        printf("2. Add Task\n");
        printf("3. Complete Task\n");
        printf("4. Exit\n");
        printf("Choose: ");
        int choice;
        scanf("%d", &choice);
        getchar(); // consume newline

        if (choice == 1) {
            listTasks(tasks, count);
        } else if (choice == 2) {
            char desc[MAX_TASK_LENGTH];
            printf("Enter task description: ");
            fgets(desc, MAX_TASK_LENGTH, stdin);
            desc[strcspn(desc, "\n")] = 0; // Remove newline
            addTask(&tasks, &count, desc);
        } else if (choice == 3) {
            int id;
            printf("Enter task ID to complete: ");
            scanf("%d", &id);
            completeTask(tasks, count, id);
        } else if (choice == 4) {
            break;
        } else {
            printf("Invalid choice.\n");
        }
    }

    free(tasks);
    return 0;
}
