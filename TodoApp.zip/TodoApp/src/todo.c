
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/todo.h"

#define FILE_PATH "data/tasks.txt"

void loadTasks(Task **tasks, int *count) {
    FILE *file = fopen(FILE_PATH, "r");
    if (!file) return;

    *count = 0;
    *tasks = NULL;
    Task temp;
    while (fscanf(file, "%d,%99[^,],%d\n", &temp.id, temp.description, &temp.completed) == 3) {
        *tasks = realloc(*tasks, sizeof(Task) * (*count + 1));
        (*tasks)[*count] = temp;
        (*count)++;
    }

    fclose(file);
}

void saveTasks(Task *tasks, int count) {
    FILE *file = fopen(FILE_PATH, "w");
    if (!file) return;

    for (int i = 0; i < count; i++) {
        fprintf(file, "%d,%s,%d\n", tasks[i].id, tasks[i].description, tasks[i].completed);
    }

    fclose(file);
}

void addTask(Task **tasks, int *count, const char *desc) {
    *tasks = realloc(*tasks, sizeof(Task) * (*count + 1));
    Task *newTask = &(*tasks)[*count];
    newTask->id = *count + 1;
    strncpy(newTask->description, desc, MAX_TASK_LENGTH);
    newTask->completed = 0;
    (*count)++;
    saveTasks(*tasks, *count);
}

void listTasks(Task *tasks, int count) {
    for (int i = 0; i < count; i++) {
        printf("[%d] %s %s\n", tasks[i].id, tasks[i].description,
               tasks[i].completed ? "(Completed)" : "");
    }
}

void completeTask(Task *tasks, int count, int id) {
    for (int i = 0; i < count; i++) {
        if (tasks[i].id == id) {
            tasks[i].completed = 1;
            break;
        }
    }
    saveTasks(tasks, count);
}
